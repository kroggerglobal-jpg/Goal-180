GOAL 180 — Android Studio project

This is the Android app project source, not a compiled APK.
The app wraps the offline GOAL 180 tracker in an Android WebView.

Features:
- No login, no OTP, no internet permission
- Daily income target: Rs 1,800
- 180-day total income target: Rs 3,24,000
- Income and expense entries, history, monthly summary
- Data saved locally on this phone
- Export/import JSON backup using Android file picker

Build an APK (requires a Windows/Mac/Linux computer with Android Studio):
1. Install Android Studio and its Android SDK (API 35).
2. Extract this ZIP.
3. In Android Studio choose File > Open and select the extracted GOAL180 folder.
4. Allow Gradle sync and SDK downloads to finish.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show the APK location, usually app/build/outputs/apk/debug/app-debug.apk.
7. Transfer that APK to your Android phone and tap it to install. Allow installation from that file manager if Android asks.

Build settings:
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Java 17
- compileSdk 35, minSdk 23

Note: Android Studio needs an internet connection the first time to download Gradle/Android SDK components. The finished GOAL 180 app itself works offline.

Data note: records are stored in the app's local WebView storage. Uninstalling the app or clearing app storage deletes those records. Use Backup > Export backup regularly and import the JSON file to restore.
